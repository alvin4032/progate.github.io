-- dapatkan total penjualan dan total laba untuk seluruh site
select sum(items.price) as "total penjualan", sum(items.price - items.cost) as "total laba"
from items
join sales_records
on items.id = sales_records.item_id;