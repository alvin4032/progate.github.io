-- dapatkan nama, harga dan laba semua produk
select name, price, price-cost
from items;