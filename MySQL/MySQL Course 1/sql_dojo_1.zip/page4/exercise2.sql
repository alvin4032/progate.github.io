-- dapatkan laba rata-rata dari semua produk
select avg(price-cost)
from items;