-- dapatkan nilai rata-rata umur semua pengguna
select avg(age)
from users;