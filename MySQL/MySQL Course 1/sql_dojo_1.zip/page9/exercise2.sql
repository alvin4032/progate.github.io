-- dapatkan id dan nama pengguna yang membeli "sandal"
select users.id, users.name
from sales_records
join users
on users.id = sales_records.user_id
join items
on items.id = sales_records.item_id
where sales_records.item_id = (
  select id
  from items
  where name = "sandal"
)

group by users.id;