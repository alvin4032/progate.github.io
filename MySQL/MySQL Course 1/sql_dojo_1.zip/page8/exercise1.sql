-- dapatkan berapa kali penjualan terjadi untuk setiap harinya
select purchased_at, count(purchased_at) as "penjualan"
from sales_records
group by purchased_at;