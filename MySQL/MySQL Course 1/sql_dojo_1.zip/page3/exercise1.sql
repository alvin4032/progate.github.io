-- dapatkan setiap nama barang unik (tanpa duplikat)
select distinct(name)
from items;

