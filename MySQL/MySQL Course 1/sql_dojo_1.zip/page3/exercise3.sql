-- dapatkan semua baris dengan nilai string "kaos"
select *
from items
where name like "%kaos%";