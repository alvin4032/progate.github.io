/*
dapatkan nama dan harga setiap produk dan
tampilkan secara mengecil berdasarkan harga
*/
select name, price
from items
order by  price desc; 